$(document).ready(function () {
    $.ajax({
        type: "get",
        url: "https://test101.ustangelicum.edu.ph/api/product/get",
        statusCode: {
            200: function (response) {
                var productTable = $(".productTable");

                for (let i = 0; i < response.length; i++) {
                    productTable.append(
                        "<tr>" +
                        "<td>" + response[i].Id + "</td>" +
                        "<td>" + response[i].Name + "</td>" +
                        "<td>" + response[i].Category + "</td>" +
                        "<td>" + response[i].Description + "</td>" +
                        "<td>" + response[i].Price + "</td>" +
                        "<td>" + "<img class='w-25' src='" + response[i].Image + "' />" + "</td>" +
                        "</tr>"

                    )
                }
            }
        }
    });

    $("#addBtn").click(function (e) {
        e.preventDefault();
        let item = {
            Name: $("#name").val(),
            Category: $("#category").val(),
            Description: $("#description").val(),
            Price: $("#price").val(),
            Image: $("#image").val()
        }
        $.ajax({
            type: "post",
            url: "https://test101.ustangelicum.edu.ph/api/product/add",
            data: item,
            statusCode: {
                200: function () {
                    $(".productTable").empty();
                    var productTable = $(".productTable");
                    $.ajax({
                        type: "get",
                        url: "https://test101.ustangelicum.edu.ph/api/product/get",
                        statusCode: {
                            200: function (response) {

                                for (let i = 0; i < response.length; i++) {
                                    productTable.append(
                                        "<tr>" +
                                        "<td>" + response[i].Id + "</td>" +
                                        "<td>" + response[i].Name + "</td>" +
                                        "<td>" + response[i].Category + "</td>" +
                                        "<td>" + response[i].Description + "</td>" +
                                        "<td>" + response[i].Price + "</td>" +
                                        "<td>" + "<img class='w-25' src='" + response[i].Image + "' />" + "</td>" +
                                        "</tr>"
                                    )
                                }
                            }
                        }
                    });
                }
            }
        });

        $("#name").val("")
        $("#category").val("")
        $("#description").val("")
        $("#price").val("")
        $("#image").val("")
    });

    $("#getBtn").click(function (e) {
        e.preventDefault();
        $.ajax({
            type: "get",
            url: "https://test101.ustangelicum.edu.ph/api/product/get/" + $("#id").val(),
            statusCode: {
                200: function (response) {
                    $("#name").val(response.Name)
                    $("#category").val(response.Category)
                    $("#description").val(response.Description)
                    $("#price").val(response.Price)
                    $("#image").val(response.Image)
                }
            }
        });
    });

    $("#updateBtn").click(function (e) {
        e.preventDefault();
        let item = {
            Name: $("#name").val(),
            Category: $("#category").val(),
            Description: $("#description").val(),
            Price: $("#price").val(),
            Image: $("#image").val()
        }
        $.ajax({
            type: "post",
            url: "https://test101.ustangelicum.edu.ph/api/product/update/" + $("#id").val(),
            data: item,
            statusCode: {
                200: function () {
                    $(".productTable").empty();
                    var productTable = $(".productTable");
                    $.ajax({
                        type: "get",
                        url: "https://test101.ustangelicum.edu.ph/api/product/get",
                        statusCode: {
                            200: function (response) {

                                for (let i = 0; i < response.length; i++) {
                                    productTable.append(
                                        "<tr>" +
                                        "<td>" + response[i].Id + "</td>" +
                                        "<td>" + response[i].Name + "</td>" +
                                        "<td>" + response[i].Category + "</td>" +
                                        "<td>" + response[i].Description + "</td>" +
                                        "<td>" + response[i].Price + "</td>" +
                                        "<td>" + "<img class='w-25' src='" + response[i].Image + "' />" + "</td>" +
                                        "</tr>"
                                    )
                                }
                            }
                        }
                    });
                }
            }
        });
        
        $("#id").val("")
        $("#name").val("")
        $("#category").val("")
        $("#description").val("")
        $("#price").val("")
        $("#image").val("")
    });

    $("#deleteBtn").click(function (e) {
        e.preventDefault();
        $.ajax({
            type: "post",
            url: "https://test101.ustangelicum.edu.ph/api/product/delete/" + $("#id").val(),
            statusCode: {
                200: function () {
                    $(".productTable").empty();
                    var productTable = $(".productTable");
                    $.ajax({
                        type: "get",
                        url: "https://test101.ustangelicum.edu.ph/api/product/get",
                        statusCode: {
                            200: function (response) {

                                for (let i = 0; i < response.length; i++) {
                                    productTable.append(
                                        "<tr>" +
                                        "<td>" + response[i].Id + "</td>" +
                                        "<td>" + response[i].Name + "</td>" +
                                        "<td>" + response[i].Category + "</td>" +
                                        "<td>" + response[i].Description + "</td>" +
                                        "<td>" + response[i].Price + "</td>" +
                                        "<td>" + "<img class='w-25' src='" + response[i].Image + "' />" + "</td>" +
                                        "</tr>"
                                    )
                                }
                            }
                        }
                    });
                }
            }
        });

        $("#id").val("")
        $("#name").val("")
        $("#category").val("")
        $("#description").val("")
        $("#price").val("")
        $("#image").val("")
    });
});